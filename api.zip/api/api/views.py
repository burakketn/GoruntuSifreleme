from django.shortcuts import render
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from django.core import serializers
from django.conf import settings
import json 
import random
from . import a   #a dosyasını tanıttık

@api_view(["POST"])    #gelen işlemi "POST" olduğunu belirtiyor.
def deneme(sayi): #sayi dışarıdan nesne olarak geliyor

    try:
        body_unicode = sayi.body.decode('utf-8')    #sayının body'sini decode ettik   
        body = json.loads(body_unicode)        #decode edilmiş json verileirni body'e attık
        bit_sayisi=body['bitsayi']  #body'nin içindeki 'bitsayi' yazan değerleri bit_sayisi parametresine attık
        sha=body['sha'] #'sha' yazanı sha parametresine attık  gelen sha'lar 1-0 lardan oluşan stringdir.
        sha3=[]  #sha3 dizisi oluşturduk
        for i in sha:  #sha'nın içerisnde döndük
            sha3.append(int(i)) #sha3 dizisine attık 0-1'leri int'e cevirerek attık.
        y=a.ip3(sha3,bit_sayisi)  #oluşan parametreleri (dizi,bitsayisi) ip3'ün fonksiyonuna gönderdik gelen değeri değeri y'ye atadık
        return JsonResponse(y,safe=False) #y'yi JSON  türünde geri döndürüp Response ettik.
    except ValueError as e:   #hata varsa Hatada alttaki kodu döndür.
        return Response(e.args[0],status.HTTP_400_BAD_REQUEST)
