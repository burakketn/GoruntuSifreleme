import random 
def ip3(sha3,bit_sayisi):



   
    random_dizi=[]
    key=[]



    ip2=[0.868108929091533,
      0.436522798444119,
      0.850347542213392,
      0.775550139264662,
      0.752164288690584,
      0.117648319430803,
      0.838178032758474]

    for i in range(0, bit_sayisi, 1000000):
        xEx=random.choice(ip2)

        for j in range(0, 1000000):
            if(len(random_dizi)>=bit_sayisi):
                break

            xNew=xEx*(1-xEx)*4

            if(xNew<0.5):
                random_dizi.append(0)

            else:
                random_dizi.append(1)


    for i in range(bit_sayisi):
        key.append(sha3[i]^random_dizi[i])

    print(bit_sayisi)
    print(len(sha3))
    print(sha3)
    print(len(random_dizi))
    print(random_dizi)
    print(len(key))
    print(key)
    return key
    
